const constants = {
  SR_LABEL: "Agregar registro",
};

export default constants;
