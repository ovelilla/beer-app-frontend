const constants = {
  SR_BUTTON_LABEL: "Abrir menú de visibilidad",
  DROPDOWN_LABEL: "Columnas",
};

export default constants;
