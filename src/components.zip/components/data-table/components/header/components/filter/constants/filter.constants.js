const constants = {
  FIELD_FILTER_PROPS: {
    placeholder: "Filtrar...",
    type: "text",
  },
};

export default constants;
