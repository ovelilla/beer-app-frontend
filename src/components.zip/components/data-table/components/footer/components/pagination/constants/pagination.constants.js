const constants = {
  SR_FIRST_PAGE: "Ir a la primera página",
  SR_PREVIOUS_PAGE: "Ir a la página anterior",
  SR_NEXT_PAGE: "Ir a la página siguiente",
  SR_LAST_PAGE: "Ir a la última página",
};

export default constants;
