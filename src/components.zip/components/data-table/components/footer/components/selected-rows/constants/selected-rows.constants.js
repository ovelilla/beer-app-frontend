const constants = {
  LABEL_SINGULAR: "fila seleccionada",
  LABEL_PLURAL: "filas seleccionadas",
};

export default constants;
