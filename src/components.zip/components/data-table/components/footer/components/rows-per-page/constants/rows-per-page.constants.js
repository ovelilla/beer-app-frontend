const constants = {
  LABEL: "Filas por página:",
  PAGE_SIZES: [10, 20, 30, 40, 50],
};

export default constants;
