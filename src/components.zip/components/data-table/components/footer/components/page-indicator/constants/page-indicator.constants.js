const constants = {
  SEPARATOR: "de",
  LABEL: "Página",
};

export default constants;
